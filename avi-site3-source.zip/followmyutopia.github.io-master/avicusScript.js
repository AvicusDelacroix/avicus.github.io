function sstad(){
    window.alert("Come on, I told you not to click me!\nNow your soul belongs to Avicus Delacroix. Forever!");
};
function aviTitButt(){
    document.getElementById("aviMain").style.display = "block";
    document.getElementById("aviPage1").style.display = "none";
    document.getElementById("aviPage2").style.display = "none";
    document.getElementById("aviPage3").style.display = "none";
    document.getElementById("aviPage4").style.display = "none";
    document.getElementById("aviTitle").innerHTML = "Main Title";
};
function aviButton1(){
    document.getElementById("aviMain").style.display = "none";
    document.getElementById("aviPage1").style.display = "block";
    document.getElementById("aviPage2").style.display = "none";
    document.getElementById("aviPage3").style.display = "none";
    document.getElementById("aviPage4").style.display = "none";
    document.getElementById("aviTitle").innerHTML = "Page1 — Main Title";
};
function aviButton2(){
    document.getElementById("aviMain").style.display = "none";
    document.getElementById("aviPage1").style.display = "none";
    document.getElementById("aviPage2").style.display = "block";
    document.getElementById("aviPage3").style.display = "none";
    document.getElementById("aviPage4").style.display = "none";
    document.getElementById("aviTitle").innerHTML = "Page2 — Main Title";
};
function aviButton3(){
    document.getElementById("aviMain").style.display = "none";
    document.getElementById("aviPage1").style.display = "none";
    document.getElementById("aviPage2").style.display = "none";
    document.getElementById("aviPage3").style.display = "block";
    document.getElementById("aviPage4").style.display = "none";
    document.getElementById("aviTitle").innerHTML = "Page3 — Main Title";
};
function aviButton4(){
    document.getElementById("aviMain").style.display = "none";
    document.getElementById("aviPage1").style.display = "none";
    document.getElementById("aviPage2").style.display = "none";
    document.getElementById("aviPage3").style.display = "none";
    document.getElementById("aviPage4").style.display = "block";
    document.getElementById("aviTitle").innerHTML = "Page4 — Main Title";
};
function testAlert(){
    window.alert("Some alert here\nHere can be literally everything.")
};